﻿using UnityEngine;
using System.Collections;

public class Skyscraper : WorldObject {
}
